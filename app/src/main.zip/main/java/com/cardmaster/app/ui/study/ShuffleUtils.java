package com.cardmaster.app.ui.study;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class ShuffleUtils {
    private ShuffleUtils() {}

    /** Trả về danh sách MỚI đã trộn; danh sách gốc (lấy từ DB) giữ nguyên. */
    public static <T> List<T> shuffled(List<T> source) {
        List<T> copy = new ArrayList<>(source);   // sao chép trước khi trộn
        Collections.shuffle(copy);
        return copy;
    }

    /** Trộn đáp án nhưng vẫn biết đáp án đúng nằm ở đâu. */
    public static QuizItem buildQuizItem(Question q, boolean shuffleOptions) {   // <<< ĐỔI: Question = class câu hỏi của nhóm
        // (1) Đáp án gốc theo thứ tự A, B, C, D
        List<String> original = Arrays.asList(q.getOptionA(), q.getOptionB(), q.getOptionC(), q.getOptionD());   // <<< ĐỔI getter
        // (2) Vị trí đáp án đúng gốc: 0=A, 1=B, 2=C, 3=D
        int correctOriginal = "ABCD".indexOf(q.getCorrectAnswer());   // <<< ĐỔI nếu DB lưu kiểu khác (số, hoặc nội dung đáp án)
        if (correctOriginal < 0) throw new IllegalStateException("Không xác định được đáp án đúng của câu " + q.getId());

        // (3) Trộn danh sách CHỈ SỐ: order.get(viTriMoi) = viTriCu
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < original.size(); i++) order.add(i);
        if (shuffleOptions) Collections.shuffle(order);

        List<String> options = new ArrayList<>();
        for (int oldIndex : order) options.add(original.get(oldIndex));

        // (4) Vị trí mới của đáp án đúng = vị trí của chỉ số cũ trong order
        int correctNew = order.indexOf(correctOriginal);
        return new QuizItem(q, options, correctNew);
    }

    /** Tạo cả phiên Quiz: trộn câu hỏi (tuỳ chọn) rồi trộn đáp án (tuỳ chọn). */
    public static List<QuizItem> buildQuizSession(List<Question> source, boolean shuffleQuestions, boolean shuffleOptions) {
        List<Question> questions = shuffleQuestions ? shuffled(source) : new ArrayList<>(source);
        List<QuizItem> session = new ArrayList<>();
        for (Question q : questions) session.add(buildQuizItem(q, shuffleOptions));
        return session;
    }
}

// ===== QuizItem.java: một câu hỏi trong phiên làm bài (đã trộn) =====
public class QuizItem {
    private final Question source;        // câu hỏi gốc, giữ lại để lấy id, phần giải thích...
    private final List<String> options;   // đáp án ĐÃ TRỘN: vị trí 0..3 = A..D trên màn hình
    private final int correctIndex;       // vị trí đáp án đúng trong danh sách đã trộn

    public QuizItem(Question source, List<String> options, int correctIndex) {
        this.source = source;
        this.options = options;
        this.correctIndex = correctIndex;
    }
    public Question getSource() { return source; }
    public List<String> getOptions() { return options; }
    public int getCorrectIndex() { return correctIndex; }

    /** Chấm theo VỊ TRÍ, không so chữ, nên vẫn đúng kể cả khi 2 đáp án có nội dung giống nhau. */
    public boolean isCorrect(int selectedIndex) { return selectedIndex == correctIndex; }
}